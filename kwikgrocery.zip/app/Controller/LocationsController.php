<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppController', 'Controller');
/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class LocationsController extends AppController {
	public $components = array('Auth','Session','Email','Upload'/* ,'Image' */);
	public $uses = array('Location');
    var $helpers = array('Html','Form');
	public $allowedActions =array();
	
	function beforeFilter() 
	{
		parent::beforeFilter();
		$this->Auth->allow($this->allowedActions);
	}
	
    function admin_cities($id = null){
	    $conditions = array();
		$search_type = "";
		if(!isset($id)){
			$this->redirect($this->referer());
		}
        $conditions['Location.parent_id '] = $id;
		if (!empty($this->params->query['search']) && trim($this->params->query['search'])!='') {
			
			$conditions['OR'] = array(
								'Location.name Like ' => '%' .$this->params->query['search'].'%',															
							);
			$this->set('search', $this->params->query['search']);
        }
		if(isset($this->request->params['named']['sort']))
		{ 
			 $params = array(
				  'conditions' => $conditions,
				  'recursive' => 0,
				  'limit' => 20
			 );
        } 
		else
		{
			 $params = array(
				  'conditions' => $conditions,
				  'recursive' => 0,
				  'order' => array('Location.id'=>'desc'),
				  'limit' => 5
			 );
		}
		$this->paginate=array('Location'=>$params);
		$user_data = $this->paginate('Location');
		//pr($user_data);die;
		$this->set('data', $user_data);
    }
    function admin_states(){
	   		
		$conditions = array();
		$search_type = "";
        $conditions['Location.parent_id'] = 0;
		if (!empty($this->params->query['search']) && trim($this->params->query['search'])!='') {
			
			$conditions['OR'] = array(
								'Location.name Like ' => '%' .$this->params->query['search'].'%',															
							);
			$this->set('search', $this->params->query['search']);
        }
		if(isset($this->request->params['named']['sort']))
		{ 
			 $params = array(
				  'conditions' => $conditions,
				  'recursive' => 0,
				  'limit' => 20
			 );
        } 
		else
		{
			 $params = array(
				  'conditions' => $conditions,
				  'recursive' => 0,
				  'order' => array('Location.id'=>'desc'),
				  'limit' => 5
			 );
		}
		$this->paginate=array('Location'=>$params);
		$user_data = $this->paginate('Location');
		$this->set('data', $user_data);
    }
    function admin_add_state(){
	   if($this->request->is('post')){
		   if($this->Location->save($this->request->data)){
			    $this->Session->setFlash('State added successfully.','default',array('class' => 'success_message'));
			    $this->redirect(array('controller'=>'locations','action'=>'admin_states'));
		   }
	   }
    }
	function admin_edit_state($id=null){
		if(!isset($id)){
			$this->redirect($this->referer());
		}		
	    if($this->request->is(array('post','put'))){
			$this->Location->id = $id;
		    if($this->Location->save($this->request->data)){
			    $this->Session->setFlash('State updated successfully.','default',array('class' => 'success_message'));
			    $this->redirect(array('controller'=>'locations','action'=>'admin_states'));
		    }
	    }else{
			$state = $this->Location->findById($id);
            $this->request->data = $state;			
		}
    }
    function admin_add_city(){
	    $states = $this->Location->find('list',array('fields'=>array('id','name'),'conditions'=>array('Location.parent_id'=>0)));
	    if(!empty($states)){
		   $this->set('states',$states);
	    }else{
		    $this->Session->setFlash('Please add state first.','default',array('class' => 'error_message'));
			$this->redirect(array('controller'=>'locations','action'=>'admin_add_state')); 
	    }
		if($this->request->is(array('post','put'))){			
			if($this->Location->save($this->request->data)){
				$this->Session->setFlash('City added successfully.','default',array('class' => 'success_message'));
			    $this->redirect(array('controller'=>'locations','action'=>'admin_cities',$this->request->data['Location']['parent_id']));
			}
		}
    }
    function admin_edit_city($id=null){
		if(!isset($id)){
			$this->redirect($this->referer());
		}
		$states = $this->Location->find('list',array('fields'=>array('id','name'),'conditions'=>array('Location.parent_id'=>0)));
	    if(!empty($states)){
		   $this->set('states',$states);
	    }else{
		    $this->Session->setFlash('Please add state first.','default',array('class' => 'error_message'));
			$this->redirect(array('controller'=>'locations','action'=>'admin_add_state')); 
	    }
	    if($this->request->is(array('post','put'))){
			$this->Location->id = $id;
		    if($this->Location->save($this->request->data)){
			    $this->Session->setFlash('City updated successfully.','default',array('class' => 'success_message'));
			    $this->redirect(array('controller'=>'locations','action'=>'admin_cities',$this->request->data['Location']['parent_id']));
		    }
	    }else{
			$city = $this->Location->findById($id);
            $this->request->data = $city;			
		}
    }
    function admin_delete_city($id=null){
		if(!isset($id)){
			$this->redirect($this->referer());
		}
		if($this->Location->delete($id)){
			$this->Session->setFlash('City Deleted successfully.','default',array('class' => 'success_message'));
			$this->redirect($this->referer());
		}
	}
    function admin_delete_state($id=null){
		if(!isset($id)){
			$this->redirect($this->referer());
		}
		if($this->Location->delete($id)){
			$this->Session->setFlash('State Deleted successfully.','default',array('class' => 'success_message'));
			$this->redirect($this->referer());
		}
	}
    function admin_changestatus($id) {	
		$data['status'] = $this->request->named['status'];
        $data['id'] = $id;		
        if($this->Location->save($data,  $validate = false)){			
			$this->Session->setFlash('Status changed successfully.','default',array('class' => 'success_message'));
			$this->redirect($this->referer());
		}
    }
    	
}